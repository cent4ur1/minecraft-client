package com.rottenapple.client.listener;

import com.rottenapple.client.RottenAppleConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.weavemc.api.event.RenderGameOverlayEvent;
import net.weavemc.api.event.SubscribeEvent;

/**
 * Applies the (few) RottenApple effects every frame and draws
 * the optional FPS overlay when no GUI is open.
 */
public class GameOverlayListener {

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent event) {
        Minecraft mc;
        try {
            mc = Minecraft.getMinecraft();
        } catch (Throwable t) {
            return;
        }
        if (mc == null || mc.gameSettings == null) return;

        // Fullbright: crank gamma while enabled, restore when disabled.
        try {
            if (RottenAppleConfig.fullbright) {
                if (mc.gameSettings.gammaSetting < 100.0f) {
                    mc.gameSettings.gammaSetting = 100.0f;
                }
            } else {
                if (mc.gameSettings.gammaSetting > 1.0f) {
                    mc.gameSettings.gammaSetting = 1.0f;
                }
            }
        } catch (Throwable ignored) {}

        // ToggleSprint: keep sprinting while moving forward.
        try {
            if (RottenAppleConfig.toggleSprint
                    && mc.thePlayer != null
                    && mc.theWorld != null
                    && mc.currentScreen == null) {
                boolean forward = mc.gameSettings.keyBindForward.isKeyDown();
                // Don't fight hunger / sneaking states.
                if (forward
                        && !mc.thePlayer.isSneaking()
                        && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
                    mc.thePlayer.setSprinting(true);
                }
            }
        } catch (Throwable ignored) {}

        // Small FPS overlay, top-left, when menu is closed.
        try {
            if (RottenAppleConfig.showFps
                    && mc.currentScreen == null
                    && mc.fontRendererObj != null) {
                ScaledResolution sr = new ScaledResolution(mc);
                String fps = mc.getDebugFPS() + " fps";
                int bg = 0xAA101014;
                Gui.drawRect(4, 4, 4 + mc.fontRendererObj.getStringWidth(fps) + 8, 17, bg);
                mc.fontRendererObj.drawStringWithShadow(fps, 8, 7, 0xFF7CFF6B);
                sr.getScaledWidth(); // keep reference, avoids unused warnings on some mappings
            }
        } catch (Throwable ignored) {}
    }
}
