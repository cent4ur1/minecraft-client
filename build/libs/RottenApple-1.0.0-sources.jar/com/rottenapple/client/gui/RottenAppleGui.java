package com.rottenapple.client.gui;

import com.rottenapple.client.RottenAppleConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

/**
 * Resizable click-GUI for RottenApple Client.
 * <ul>
 *   <li>Drag the title bar to move.</li>
 *   <li>Drag the bottom-right corner to resize.</li>
 *   <li>INSERT or ESC closes.</li>
 * </ul>
 */
public class RottenAppleGui extends GuiScreen {

    private static final String TITLE = "RottenApple Client";

    private static final int TITLE_BAR_H = 20;
    private static final int RESIZE_HANDLE = 16;
    private static final int MIN_W = 210;
    private static final int MIN_H = 150;
    private static final int PAD = 10;
    private static final int ROW_H = 24;

    // Persisted across opens so resize "sticks".
    private static int winX = 60;
    private static int winY = 60;
    private static int winW = 270;
    private static int winH = 178;

    private boolean dragging = false;
    private boolean resizing = false;
    private boolean sliderDragging = false;
    private int dragOffX, dragOffY;
    private int resizeStartX, resizeStartY, resizeStartW, resizeStartH;

    private static final int KEY_INSERT = 210;

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        // First open: center-ish if never positioned.
        if (winX < 0 && winY < 0) {
            winX = (width - winW) / 2;
            winY = (height - winH) / 2;
        }
        clampToScreen();
    }

    @Override
    public void onGuiClosed() {
        RottenAppleConfig.clamp();
        dragging = false;
        resizing = false;
        sliderDragging = false;
    }

    // ---------- rendering ----------

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        clampToScreen();

        int x = winX, y = winY, w = winW, h = winH;
        float op = RottenAppleConfig.menuOpacity;

        int bg = withAlpha(0x141419, op);
        int titleBg = withAlpha(0x1F1F26, Math.min(1.0f, op + 0.05f));
        int border = 0xFF2A2A32;
        int accent = 0xFFE5484D;

        // Shadow + body
        Gui.drawRect(x + 3, y + 3, x + w + 3, y + h + 3, 0x55000000);
        Gui.drawRect(x, y, x + w, y + h, bg);
        // Border (1px)
        Gui.drawRect(x, y, x + w, y + 1, border);
        Gui.drawRect(x, y + h - 1, x + w, y + h, border);
        Gui.drawRect(x, y, x + 1, y + h, border);
        Gui.drawRect(x + w - 1, y, x + w, y + h, border);

        // Title bar
        Gui.drawRect(x, y, x + w, y + TITLE_BAR_H, titleBg);
        Gui.drawRect(x, y + TITLE_BAR_H - 1, x + w, y + TITLE_BAR_H, accent);
        this.fontRendererObj.drawStringWithShadow(TITLE, x + PAD, y + 6, 0xFFFFFFFF);
        String hint = "[INS]";
        this.fontRendererObj.drawStringWithShadow(hint,
                x + w - PAD - this.fontRendererObj.getStringWidth(hint), y + 6, 0xFF8A8A93);

        // Rows
        int contentY = y + TITLE_BAR_H + PAD;
        int rowW = w - PAD * 2;
        drawToggleRow(mouseX, mouseY, x + PAD, contentY, rowW, "Toggle Sprint", RottenAppleConfig.toggleSprint);
        drawToggleRow(mouseX, mouseY, x + PAD, contentY + ROW_H, rowW, "Fullbright", RottenAppleConfig.fullbright);
        drawToggleRow(mouseX, mouseY, x + PAD, contentY + ROW_H * 2, rowW, "Show FPS", RottenAppleConfig.showFps);
        drawSliderRow(mouseX, x + PAD, contentY + ROW_H * 3, rowW);

        // Footer hint (only if tall enough)
        if (h >= MIN_H + 18) {
            String footer = "drag title to move - corner to resize";
            this.fontRendererObj.drawString(footer, x + PAD, y + h - 13, 0xFF6E6E78);
        }

        // Resize handle (bottom-right)
        int hx = x + w - RESIZE_HANDLE;
        int hy = y + h - RESIZE_HANDLE;
        boolean hoverResize = mouseX >= hx && mouseX <= x + w && mouseY >= hy && mouseY <= y + h;
        int handleCol = hoverResize ? accent : 0xFF55555F;
        for (int i = 0; i < 4; i++) {
            int yy = y + h - 3 - i * 4;
            int xx = x + w - 3 - i * 4;
            Gui.drawRect(xx, yy, x + w - 2, yy + 1, handleCol);
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawToggleRow(int mouseX, int mouseY, int rx, int ry, int rowW, String label, boolean on) {
        this.fontRendererObj.drawString(label, rx, ry + 4, 0xFFD7D7DE);

        int pillW = 42, pillH = 14;
        int px = rx + rowW - pillW;
        int py = ry;
        boolean hover = mouseX >= px && mouseX <= px + pillW && mouseY >= py && mouseY <= py + pillH;
        int pillBg = on ? 0xFF2E7D32 : (hover ? 0xFF3A3A44 : 0xFF2B2B33);
        Gui.drawRect(px, py, px + pillW, py + pillH, pillBg);
        String s = on ? "ON" : "OFF";
        this.fontRendererObj.drawString(s,
                px + (pillW - this.fontRendererObj.getStringWidth(s)) / 2, py + 3, on ? 0xFFB6FFB6 : 0xFFAAAAAA);
    }

    private void drawSliderRow(int mouseX, int rx, int ry, int rowW) {
        this.fontRendererObj.drawString("Menu opacity", rx, ry - 8, 0xFFD7D7DE);
        int trackY = ry + 6;
        int trackH = 5;
        Gui.drawRect(rx, trackY, rx + rowW, trackY + trackH, 0xFF2B2B33);
        float t = (RottenAppleConfig.menuOpacity - 0.4f) / 0.6f;
        int fillW = (int) (rowW * t);
        Gui.drawRect(rx, trackY, rx + fillW, trackY + trackH, 0xFFE5484D);
        int knobW = 6;
        int knobX = rx + fillW - knobW / 2;
        if (knobX < rx) knobX = rx;
        if (knobX + knobW > rx + rowW) knobX = rx + rowW - knobW;
        Gui.drawRect(knobX, trackY - 3, knobX + knobW, trackY + trackH + 3, 0xFFFFFFFF);
        String pct = (int) (RottenAppleConfig.menuOpacity * 100) + "%";
        this.fontRendererObj.drawString(pct, rx + rowW - this.fontRendererObj.getStringWidth(pct), ry - 8, 0xFF8A8A93);
    }

    // ---------- input ----------

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton != 0) return;

        int x = winX, y = winY, w = winW, h = winH;

        // Outside window: ignore.
        if (mouseX < x || mouseX > x + w || mouseY < y || mouseY > y + h) return;

        // 1) Resize handle wins over everything.
        if (mouseX >= x + w - RESIZE_HANDLE && mouseY >= y + h - RESIZE_HANDLE) {
            resizing = true;
            resizeStartX = mouseX;
            resizeStartY = mouseY;
            resizeStartW = w;
            resizeStartH = h;
            return;
        }

        // 2) Title bar drag.
        if (mouseY <= y + TITLE_BAR_H) {
            dragging = true;
            dragOffX = mouseX - x;
            dragOffY = mouseY - y;
            return;
        }

        // 3) Slider track.
        int contentY = y + TITLE_BAR_H + PAD;
        int rx = x + PAD;
        int rowW = w - PAD * 2;
        int sliderY = contentY + ROW_H * 3;
        if (mouseY >= sliderY - 4 && mouseY <= sliderY + 16
                && mouseX >= rx && mouseX <= rx + rowW) {
            sliderDragging = true;
            applySlider(mouseX);
            return;
        }

        // 4) Toggle rows.
        if (hitToggle(mouseX, mouseY, rx, contentY, rowW)) {
            RottenAppleConfig.toggleSprint = !RottenAppleConfig.toggleSprint;
            return;
        }
        if (hitToggle(mouseX, mouseY, rx, contentY + ROW_H, rowW)) {
            RottenAppleConfig.fullbright = !RottenAppleConfig.fullbright;
            if (!RottenAppleConfig.fullbright && Minecraft.getMinecraft().gameSettings != null) {
                Minecraft.getMinecraft().gameSettings.gammaSetting = 1.0f;
            }
            return;
        }
        if (hitToggle(mouseX, mouseY, rx, contentY + ROW_H * 2, rowW)) {
            RottenAppleConfig.showFps = !RottenAppleConfig.showFps;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        if (dragging) {
            winX = mouseX - dragOffX;
            winY = mouseY - dragOffY;
            clampToScreen();
        } else if (resizing) {
            winW = Math.max(MIN_W, resizeStartW + (mouseX - resizeStartX));
            winH = Math.max(MIN_H, resizeStartH + (mouseY - resizeStartY));
            // Keep resize on-screen: shrink if it would overflow.
            if (winX + winW > width) winW = Math.max(MIN_W, width - winX);
            if (winY + winH > height) winH = Math.max(MIN_H, height - winY);
        } else if (sliderDragging) {
            applySlider(mouseX);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        dragging = false;
        resizing = false;
        sliderDragging = false;
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        super.keyTyped(typedChar, keyCode);
        if (keyCode == KEY_INSERT || keyCode == 1) { // INSERT or ESC
            this.mc.displayGuiScreen(null);
        }
    }

    // ---------- helpers ----------

    private boolean hitToggle(int mouseX, int mouseY, int rx, int ry, int rowW) {
        int pillW = 42, pillH = 14;
        int px = rx + rowW - pillW;
        return mouseX >= rx && mouseX <= rx + rowW && mouseY >= ry - 2 && mouseY <= ry + pillH + 2
                && mouseX >= px - 6; // generous: whole right side + label row
    }

    private void applySlider(int mouseX) {
        int rx = winX + PAD;
        int rowW = winW - PAD * 2;
        float t = (float) (mouseX - rx) / (float) rowW;
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        RottenAppleConfig.menuOpacity = 0.4f + t * 0.6f;
    }

    private void clampToScreen() {
        if (width == 0 || height == 0) return;
        if (winW < MIN_W) winW = MIN_W;
        if (winH < MIN_H) winH = MIN_H;
        if (winX + winW > width) winX = Math.max(0, width - winW);
        if (winY + winH > height) winY = Math.max(0, height - winH);
        if (winX < 0) winX = 0;
        if (winY < 0) winY = 0;
    }

    private static int withAlpha(int rgb, float opacity) {
        if (opacity < 0f) opacity = 0f;
        if (opacity > 1f) opacity = 1f;
        int a = Math.round(255 * opacity);
        return (a << 24) | (rgb & 0x00FFFFFF);
    }
}
