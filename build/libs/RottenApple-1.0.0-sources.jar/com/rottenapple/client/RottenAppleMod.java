package com.rottenapple.client;

import com.rottenapple.client.gui.RottenAppleGui;
import com.rottenapple.client.listener.GameOverlayListener;
import net.minecraft.client.Minecraft;
import net.weavemc.api.ModInitializer;
import net.weavemc.api.event.EventBus;
import net.weavemc.api.event.KeyboardEvent;
import org.jetbrains.annotations.NotNull;

import java.lang.instrument.Instrumentation;

/**
 * RottenApple Client - simple Lunar 1.8.9 utility mod (Weave).
 * Press INSERT (keycode 210) to open the resizable menu.
 */
public class RottenAppleMod implements ModInitializer {

    /** LWJGL Keyboard.KEY_INSERT */
    public static final int KEY_INSERT = 210;

    @Override
    public void init() {
        System.out.println("[RottenApple] Initialized");

        // Per-frame effects (sprint / fullbright / fps overlay).
        EventBus.subscribe(new GameOverlayListener());

        // INSERT opens the menu. Guard with currentScreen == null so a
        // release/repeat event right after opening doesn't double-toggle.
        EventBus.subscribe(KeyboardEvent.class, (e) -> {
            if (e.getKeyCode() != KEY_INSERT) return;
            try {
                Minecraft mc = Minecraft.getMinecraft();
                if (mc == null || mc.currentScreen != null) return;
                mc.addScheduledTask(() -> {
                    if (mc.currentScreen == null) {
                        mc.displayGuiScreen(new RottenAppleGui());
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }

    @Override
    public void preInit(@NotNull Instrumentation instrumentation) {
        System.out.println("[RottenApple] preInit");
    }
}
